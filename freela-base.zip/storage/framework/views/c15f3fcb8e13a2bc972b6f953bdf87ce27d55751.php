<svg viewBox="0 0 316 316" xmlns="http://www.w3.org/2000/svg" <?php echo e($attributes); ?>>

    <img src="<?php echo e(asset('images/cia7.png')); ?>" alt="" class="w-32 pb-4">
</svg>
<?php /**PATH D:\jobs\workana\freela-base\resources\views/components/application-logo.blade.php ENDPATH**/ ?>