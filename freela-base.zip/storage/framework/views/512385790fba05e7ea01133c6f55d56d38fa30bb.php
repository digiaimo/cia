<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200 text-center">
                    STATUS DO PERFIL: <?php echo e($status); ?>

                </div>
            </div>
        </div>
    </div>


     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Usuário ') . auth()->user()->name); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <?php if(! is_null($self) && auth()->user()->role_id != 1): ?>

        <div class="flex justify-center ">

            <div class="py-12">
                <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                        <div class="p-6 bg-white border-b border-gray-200">
                            <h2 class="text-center">Usuário</h2>
                            <table class="table table-bordered">
                                <thead class="thead-dark">
                                <tr>
                                    <th scope="col">ID</th>
                                    <th scope="col">NOME</th>
                                    <th scope="col">CNPJ</th>
                                    <th scope="col">RAZÃO SOCIAL</th>
                                    <th scope="col">TELEFONE</th>
                                    <th scope="col">STATUS</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <th scope="row"><?php echo e($user->id); ?></th>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->cnpj); ?></td>
                                    <td><?php echo e($user->razao_social); ?></td>
                                    <td><?php echo e($user->celphone); ?></td>
                                    <td><?php echo e($user->statusCliente->status); ?></td>
                                </tr>
                                </tbody>
                            </table>

                            <table class="table table-bordered">
                                <thead class="thead-dark">
                                <tr>
                                    <th scope="col">ID</th>
                                    <th scope="col">WEBSITE</th>
                                    <th scope="col">FATURAMENTO DO ULTIMO MÊS</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <th scope="row"><?php echo e($user->id); ?></th>
                                    <td><?php echo e($user->informacoesBasicas->website); ?></td>
                                    <td><?php echo e($user->informacoesBasicas->faturamento_ultimo_mes); ?></td>
                                </tr>
                                </tbody>
                            </table>

                            <table class="table table-bordered">
                                <thead class="thead-dark">
                                <tr class="text-center">
                                    <th scope="col">ID</th>
                                    <th scope="col">CONTRATO SOCIAL</th>
                                </tr>
                                </thead>
                                <tbody class="text-center">
                                <?php $__currentLoopData = $user->informacoesBasicas->contatosSociais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contrato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($user->id); ?></th>
                                        <td><a href="<?php echo e(env('APP_URL')); ?>/storage/<?php echo e($contrato->caminho_arquivo); ?>"
                                               target="_blank">
                                                <button class="bg-dark border-b border-dark text-white w-100">Ver
                                                </button>
                                            </a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                            <table class="table table-bordered">
                                <thead class="thead-dark">
                                <tr class="text-center">
                                    <th scope="col">ID</th>
                                    <th scope="col">SELF</th>
                                    <th scope="col">BAIXAR</th>
                                    <th scope="col">Deletar</th>
                                </tr>
                                </thead>
                                <tbody class="text-center">
                                <?php if($user->informacoesBasicas->selfs->count() != 0 ): ?>
                                    <?php $__currentLoopData = $user->informacoesBasicas->selfs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $self): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($user->id); ?></th>
                                            <td><a href="<?php echo e(env('APP_URL')); ?>/storage/<?php echo e($self->caminho_arquivo); ?>"
                                                   target="_blank">
                                                    <button class="bg-white border-b border-gray-200 text-dark
                                            w-100">Ver
                                                    </button>
                                                </a></td>
                                            <td><a href="<?php echo e(route('download.self', ['self' => $self->id])); ?>">
                                                    <button
                                                        class="bg-white border-b border-gray-200 text-dark
                                            w-100">Baixar
                                                    </button>
                                                </a></td>
                                            <td>
                                                <form action="<?php echo e(route('admin.sef_delet', ['user' => $user->id])); ?>"
                                                      method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="number" hidden name="self_id" value="<?php echo e($self->id); ?>">
                                                    <button type="submit" name="self"
                                                            value="<?php echo e($self->caminho_arquivo); ?>"
                                                            class="bg-white border-b border-gray-200 text-dark
                                            w-100">Deletar
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>

                                </tbody>
                            </table>
                            <?php if($user->informacoesBasicas->selfs->count() == 0 ): ?>
                                <h3 class="text-center text-red-900">SEM SELF</h3>
                                <hr class="bg-dark">
                            <?php endif; ?>

                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <div class="flex justify-center">

                <?php if(is_null($self) && auth()->user()->role_id != 1): ?>
                    <?php echo $__env->make('components.self_null', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>

                <?php if($user->informacoesBasicas->contatosSociais->count() === 0 && auth()->user()->role_id != 1): ?>
                    <?php echo $__env->make('components.contrato_null', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>

            </div>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH D:\jobs\workana\freela-base\resources\views/dashboard.blade.php ENDPATH**/ ?>