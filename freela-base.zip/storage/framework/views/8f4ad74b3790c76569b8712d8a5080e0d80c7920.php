<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard Admin')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="flex justify-center ">

        <div id="chart" style="height: 300px; width: 450px">
            <h2 class="text-center m-2">Total de Usuários</h2>
            <?php $__env->startPush('js'); ?>
                <script>
                    const chart = new Chartisan({
                        el: "#chart",
                        url: "<?php echo route('charts.'.'sample_chart'); ?>",
                    })
                </script>
            <?php $__env->stopPush(); ?>
        </div>

        <div id="status" style="height: 300px; width: 450px">
            <h2 class="text-center m-2">Status dos Clientes</h2>
            <?php $__env->startPush('js'); ?>
                <script>
                    const status = new Chartisan({
                        el: "#status",
                        url: "<?php echo route('charts.'.'status_chart'); ?>",
                    })
                </script>
            <?php $__env->stopPush(); ?>
        </div>

    </div>

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH D:\jobs\workana\freela-base\resources\views/admin/dashboard_admin.blade.php ENDPATH**/ ?>