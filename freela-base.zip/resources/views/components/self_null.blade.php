<div class="flex justify-center ">
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-red-600 border-b border-gray-200 text-center">
                    <a href="{{ route('create.self') }}">
                        <Button class="text-white"> Tirar Self</Button>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>


